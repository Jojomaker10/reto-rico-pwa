# RR Backend (USDT TRC20)

- API en Express con Sequelize (PostgreSQL) y TronWeb (TRC20)
- Rutas: `/api/deposits/*`, `/api/withdrawals/*`
- Copia `.env.example` a `.env` y ajusta credenciales

## Scripts

- `npm run dev` - desarrollo
- `npm start` - producción
- `npm run cron` - ejecuta escaneo puntual


