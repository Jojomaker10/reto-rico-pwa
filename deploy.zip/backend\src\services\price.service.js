export async function getUSDTtoUSD() {
  return 1.0
}


