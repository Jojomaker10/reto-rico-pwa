import express from 'express'
import cors from 'cors'
import helmet from 'helmet'
import morgan from 'morgan'
import path from 'path'
import { fileURLToPath } from 'url'
import 'dotenv/config'
import depositsRoutes from './routes/deposits.routes.js'
import withdrawalsRoutes from './routes/withdrawals.routes.js'
import usersRoutes from './routes/users.routes.js'
import adminRoutes from './routes/admin.routes.js'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

const app = express()

// CORS solo en desarrollo, en producción el frontend y backend están en el mismo dominio
const isProduction = process.env.NODE_ENV === 'production'
if (!isProduction) {
  app.use(cors({ origin: process.env.CLIENT_ORIGIN || '*', credentials: true }))
}

app.use(helmet({
  contentSecurityPolicy: false // Permite que el frontend funcione correctamente
}))
app.use(express.json())
app.use(morgan('dev'))

// API Routes
app.use('/api/deposits', depositsRoutes)
app.use('/api/withdrawals', withdrawalsRoutes)
app.use('/api/users', usersRoutes)
app.use('/api/admin', adminRoutes)

app.get('/health', (_req, res) => res.json({ ok: true }))

// Servir frontend build (React) en producción
if (isProduction) {
  // Ruta al directorio dist (dos niveles arriba desde src/)
  const distPath = path.resolve(__dirname, '../../dist')
  app.use(express.static(distPath))
  
  // Todas las rutas no-API van al index.html (para React Router)
  app.get('*', (_req, res) => {
    res.sendFile(path.join(distPath, 'index.html'))
  })
}

export default app


